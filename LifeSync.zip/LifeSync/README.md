# LifeSync
Project for team Fire Force
